﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupo_El_Comercio_Examen_P01
{
    public class CompleteRange
    {   
        //Creamos la estructura de datos de tipo Pila (Stack) para almacenar el máximo número entero.
        Stack<int> stkMaxEntero;
        int iMinEntero;

        public CompleteRange()
        {
            stkMaxEntero = new Stack<int>();
            iMinEntero = 1; //Definimos el mínimo número entero = 1.
        }

        public int[] build(int[] liEnteros)
        {
            //Obtenemos el máximo número entero 
            foreach(int i in liEnteros)
            {
                //Si "stkMaxEntero" está vacía, colocamos al primer número como "posible" máximo número entero.
                if (stkMaxEntero.Count == 0)
                    stkMaxEntero.Push(i);
                
                //Caso contrario, evaluamos si el actual número entero es mayor al máximo número entero almacenado en "stkMaxEntero".
                //Si es mayor, entonces colocamos al nuevo máximo número entero en "stkMaxEnteroW
                else if (i > stkMaxEntero.Peek())
                    stkMaxEntero.Push(i);
            }
            //Finalmente generamos el arreglo de enteros usando el método Range de la Clase Enumerable
            //PAra ello utilizamo el valor mínimo "1", almacenado en iMinEntero y el valor máximo, almacenado en stkMaxEntero
            return Enumerable.Range(iMinEntero, stkMaxEntero.Peek()).ToArray();

        }
    }
}
