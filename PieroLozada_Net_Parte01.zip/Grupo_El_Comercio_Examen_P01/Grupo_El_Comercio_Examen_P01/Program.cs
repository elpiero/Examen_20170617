﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupo_El_Comercio_Examen_P01
{
    class Program
    {
        static void Main(string[] args)
        {/*
            MoneyParts mp = new MoneyParts();
            Console.WriteLine("Empezamos con 0.2");
            Console.WriteLine(mp.Build("0.2"));
            Console.WriteLine("Empezamos con 0.1");
            Console.WriteLine(mp.Build("0.1"));
          */
        }
    }
}
