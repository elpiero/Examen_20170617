﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupo_El_Comercio_Examen_P01
{
    public class MoneyParts
    {
       
      

        public MoneyParts()
        {
            
           
        }

        //Creamos la clase "CombinationSolution" que almacena todas las denominaciones y almacenará todas las posibles combinaciones
        public class CombinationSolution
        {

            public decimal[] denoms; //Almacena las denominaciones
            public List<String> result; //Almacena las posibles combinaciones para un determinado monto.

            public CombinationSolution()
            {
                denoms = new decimal[] { 0.05m,0.1m, 0.2m, 0.5m, 1, 2, 5, 10, 20, 50, 100, 200 };
                result = new List<String>();
            }
            
        }
     

        public String Build(string sMonto)
        {
            CombinationSolution csolution = new CombinationSolution();
            Decimal dMonto;

            if (Decimal.TryParse(sMonto, out dMonto))
            {
                calculateCombinations("", dMonto, csolution, 0);
                return string.Join(" | ", csolution.result);  //Utilizamos "join" para unir los elementos de un arreglo y juntarlos en un "string".
            }
            else return "";

            
        }

       
        public void calculateCombinations(string solution, decimal dMonto, CombinationSolution cSolution, int index)
        {
          
            for (int i = index; i < cSolution.denoms.Length; i++)
            {
                string  tempSolution = "";
                decimal montoDenom = cSolution.denoms[i]; //Obtenemos una determinada denominación.
                decimal montoRestante = dMonto - montoDenom; //Producto de la resta del Monto por procesar - el monto de una determinada denominación.

                tempSolution = solution + "" + montoDenom + ","; //almacenamos temporalmente las denominaciones para una posible solución.

                //En este caso no se encontró una solución.
                //ej: para un monto de 0.25, se tiene la posible solución --> 0.1,0.1,0.1 ---> 0.25 - 0.3 = -0.05)
                //al salir valor negativo, se entiende que se otorgó más de lo debido.
                if (montoRestante < 0.00m)
                {
                    break;
                }

                //En este caso se encontró una solución
                if (montoRestante == 0.00m)
                {
                    cSolution.result.Add(tempSolution);//procedemos a almacenar dicha solución (ej: para un monto de 0.2--> 0.1,0.1).
                    break;
                }
                else
                {
                    //invocamos al método recursivo para probar con las denominaciones restantes en base al monto por procesar(monto restante).
                    calculateCombinations(tempSolution, montoRestante, cSolution, i);
                }
            }

        }

    }
}
