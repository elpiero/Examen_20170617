﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Grupo_El_Comercio_Examen_P01
{
    public class ChangeString
    {
        //Creamos el HashTable para optimizar las búsquedas
        Hashtable htABC;

        public ChangeString()
        {
           
            htABC = new Hashtable();

            char[] alphaM = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray(); //Alfabeto en Mayúsculas.
            char[] alpham = "abcdefghijklmnopqrstuvwxyz".ToCharArray(); //Alfabeto en Minúsculas.

            //Adicionamos elementos al HashTable correspondiente al Alfabeto en Mayúsculas.
            for (int i = 0; i < alphaM.Length; i++)
            {
                if (i == alphaM.Length - 1)
                {
                    htABC.Add(alphaM[i], alphaM[0]);
                    break;
                }
                htABC.Add(alphaM[i], alphaM[i + 1]);
            }

            //Adicionamos elementos al HashTable correspondiente al Alfabeto en Minúsculas.
            for (int i = 0; i < alpham.Length; i++)
            {
                if (i == alpham.Length - 1)
                {
                    htABC.Add(alpham[i], alpham[0]);
                    break;
                }
                htABC.Add(alpham[i], alpham[i + 1]);
            }
        }

        public string build(string sCadena)
        {
            string sCadenaRetorno = "";

            
            foreach(var c in sCadena)
            {
                //Si el carácter está presente en el HashTable que cotiene el alfabeto.
                if (htABC.ContainsKey(c))
                    //a través de la llave del HashTable retornamos el valor, el cual es la siguiente letra del alfabeto.
                    sCadenaRetorno += htABC[c];
                else
                    //Caso contrario, se mantiene el carácter.
                    sCadenaRetorno += c;

            }
            return sCadenaRetorno;
        }
    }
}
